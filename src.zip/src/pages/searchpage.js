import React from 'react';

export default function SearchPage() {
  return (
    <div style={{ padding: '20px', color: 'var(--text)' }}>
      <h2>🔍 Search & Filters</h2>
      <p>This page will include advanced filters and search functionality in the future.</p>
    </div>
  );
}
