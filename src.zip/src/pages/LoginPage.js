import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    if (!username.trim()) return alert('Please enter a username');
    localStorage.setItem('kashi_user', username.trim());
    navigate('/');
  };

  return (
    <div style={{ padding: '30px', maxWidth: '400px', margin: '0 auto', color: 'var(--text)' }}>
      <h2>Welcome to Kashi 👋</h2>
      <p>Enter your username to continue:</p>
      <input
        type="text"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        placeholder="e.g. jasser"
        style={{
          width: '100%',
          padding: '10px',
          marginBottom: '15px',
          backgroundColor: 'var(--bg)',
          color: 'var(--text)',
          border: '1px solid var(--accent)',
          borderRadius: '6px',
        }}
      />
      <button
        onClick={handleLogin}
        style={{
          width: '100%',
          backgroundColor: 'var(--accent)',
          color: '#fff',
          padding: '10px',
          border: 'none',
          borderRadius: '6px',
          cursor: 'pointer',
        }}
      >
        Log In
      </button>
    </div>
  );
}
