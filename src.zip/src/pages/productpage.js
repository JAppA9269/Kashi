import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getAllProducts } from '../data/productManager';

export default function ProductPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = getAllProducts().find((p) => p.id.toString() === id);

  const storageKey = `comments_product_${id}`;
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');

  const images = product?.images || (product?.image ? [product.image] : []);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const stored = localStorage.getItem(storageKey);
    if (stored) {
      setComments(JSON.parse(stored));
    }
  }, [storageKey]);

  const handlePostComment = () => {
    if (!newComment.trim()) return;
    const newEntry = {
      text: newComment.trim(),
      avatar: `https://api.dicebear.com/6.x/personas/svg?seed=${Math.random() * 1000}`,
      timestamp: new Date().toLocaleString(),
    };
    const updated = [...comments, newEntry];
    setComments(updated);
    localStorage.setItem(storageKey, JSON.stringify(updated));
    setNewComment('');
  };

  const handleNext = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const handlePrev = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  if (!product) {
    return <h2 style={{ padding: '20px', color: 'var(--text)' }}>Product not found</h2>;
  }

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', color: 'var(--text)' }}>
      <button
        onClick={() => navigate(-1)}
        style={{
          marginBottom: '15px',
          background: 'none',
          border: '1px solid var(--accent)',
          padding: '6px 10px',
          borderRadius: '6px',
          cursor: 'pointer',
          color: 'var(--text)'
        }}
      >
        ← Back
      </button>

      {/* Image Carousel */}
      <div style={{ position: 'relative', marginBottom: '20px' }}>
        <img
          src={images[currentImageIndex]}
          alt={`product-img-${currentImageIndex}`}
          style={{ width: '100%', borderRadius: '10px', maxHeight: 400, objectFit: 'cover' }}
        />
        {images.length > 1 && (
          <>
            <button onClick={handlePrev} style={carouselBtn('left')}>←</button>
            <button onClick={handleNext} style={carouselBtn('right')}>→</button>
          </>
        )}
      </div>

      <h2>{product.title}</h2>
      <p style={{ fontWeight: 'bold', color: 'var(--accent)' }}>{product.price}</p>
      <p>{product.description}</p>

      {/* Comments */}
      <div style={{ marginTop: '30px' }}>
        <h4>Comments</h4>
        {comments.length === 0 && <p style={{ color: '#666' }}>No comments yet. Be the first!</p>}
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {comments.map((c, i) => (
            <li
              key={i}
              style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '10px',
                marginBottom: '10px',
                borderBottom: '1px solid #eee',
                paddingBottom: '10px'
              }}
            >
              <img src={c.avatar} alt="avatar" style={{ width: 40, height: 40, borderRadius: '50%' }} />
              <div>
                <p style={{ margin: 0 }}>{c.text}</p>
                <small style={{ color: '#999' }}>{c.timestamp}</small>
              </div>
            </li>
          ))}
        </ul>

        <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
          <input
            type="text"
            placeholder="Add a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handlePostComment()}
            style={{
              flex: 1,
              padding: '10px',
              borderRadius: '6px',
              border: '1px solid var(--accent)',
              color: 'var(--text)',
              backgroundColor: 'var(--bg)',
            }}
          />
          <button
            onClick={handlePostComment}
            style={{
              backgroundColor: 'var(--accent)',
              color: '#fff',
              border: 'none',
              padding: '10px 15px',
              borderRadius: '6px',
              cursor: 'pointer',
            }}
          >
            Post
          </button>
        </div>
      </div>
    </div>
  );
}

function carouselBtn(position) {
  return {
    position: 'absolute',
    top: '50%',
    [position]: '10px',
    transform: 'translateY(-50%)',
    background: 'rgba(0,0,0,0.4)',
    color: 'white',
    border: 'none',
    borderRadius: '50%',
    width: '32px',
    height: '32px',
    cursor: 'pointer',
  };
}
