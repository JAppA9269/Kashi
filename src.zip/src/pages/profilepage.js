import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getAllProducts } from '../data/productManager';
import ProductCard from '../components/ProductCard';

export default function ProfilePage() {
  const { username } = useParams();
  const navigate = useNavigate();
  const loggedInUser = localStorage.getItem('kashi_user');
  const isOwnProfile = username === loggedInUser;

  const [bio, setBio] = useState('');
  const [photo, setPhoto] = useState('');
  const [followers, setFollowers] = useState([]);
  const [following, setFollowing] = useState([]);
  const [activeTab, setActiveTab] = useState('listings');
  const [editMode, setEditMode] = useState(false);
  const [showThumbnails, setShowThumbnails] = useState(localStorage.getItem('kashi_show_thumbnails') !== 'true');

  useEffect(() => {
    const profile = JSON.parse(localStorage.getItem(`profile_${username}`)) || {};
    setBio(profile.bio || '');
    setPhoto(profile.photo || '');

    const storedFollowers = JSON.parse(localStorage.getItem(`followers_${username}`)) || [];
    const storedFollowing = JSON.parse(localStorage.getItem(`following_${username}`)) || [];

    setFollowers(storedFollowers);
    setFollowing(storedFollowing);

    if (isOwnProfile) {
      localStorage.setItem(`follow_notif_${username}`, '0');
    }
  }, [username, isOwnProfile]);

  const saveProfile = () => {
    localStorage.setItem(`profile_${username}`, JSON.stringify({ bio, photo }));
    setEditMode(false);
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => setPhoto(reader.result);
    reader.readAsDataURL(file);
  };

  const handleFollow = () => {
    const updatedFollowers = [...new Set([...followers, loggedInUser])];
    const updatedFollowing = [...new Set([...(JSON.parse(localStorage.getItem(`following_${loggedInUser}`)) || []), username])];

    localStorage.setItem(`followers_${username}`, JSON.stringify(updatedFollowers));
    localStorage.setItem(`following_${loggedInUser}`, JSON.stringify(updatedFollowing));

    const notif = parseInt(localStorage.getItem(`follow_notif_${username}`) || '0');
    localStorage.setItem(`follow_notif_${username}`, (notif + 1).toString());

    setFollowers(updatedFollowers);
  };

  const handleUnfollow = () => {
    const updatedFollowers = followers.filter((u) => u !== loggedInUser);
    const updatedFollowing = (JSON.parse(localStorage.getItem(`following_${loggedInUser}`)) || []).filter((u) => u !== username);

    localStorage.setItem(`followers_${username}`, JSON.stringify(updatedFollowers));
    localStorage.setItem(`following_${loggedInUser}`, JSON.stringify(updatedFollowing));

    setFollowers(updatedFollowers);
  };

  const handleToggleThumbnails = () => {
    const newVal = !showThumbnails;
    setShowThumbnails(newVal);
    localStorage.setItem('kashi_show_thumbnails', newVal.toString());
  };

  const isFollowing = followers.includes(loggedInUser);
  const userProducts = getAllProducts().filter((p) => p.username === username);
  const followersData = followers.map((user) => ({ username: user, ...getProfile(user) }));
  const followingData = following.map((user) => ({ username: user, ...getProfile(user) }));
  const notifCount = parseInt(localStorage.getItem(`follow_notif_${loggedInUser}`) || '0');
  const avatar = photo || generateAvatar(username);

  return (
    <div style={{ padding: '20px', maxWidth: '700px', margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px', marginBottom: '10px' }}>
        <img
          src={avatar}
          alt="Profile"
          style={{ width: 100, height: 100, borderRadius: '50%', objectFit: 'cover' }}
        />
        {isOwnProfile && !editMode && (
          <button onClick={() => setEditMode(true)} style={editButtonStyle}>✏️ Edit Profile</button>
        )}
      </div>

      {/* Bio / Edit */}
      {isOwnProfile && editMode ? (
        <div style={{ marginBottom: '20px' }}>
          <textarea
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            placeholder="Your bio..."
            rows={3}
            style={{ width: '100%', marginBottom: '10px' }}
          />
          <input type="file" accept="image/*" onChange={handlePhotoChange} />
          <button onClick={saveProfile} style={saveButtonStyle}>💾 Save</button>
        </div>
      ) : (
        <p style={{ marginBottom: '10px' }}>{bio || 'No bio available.'}</p>
      )}

      {/* Follow Button */}
      {!isOwnProfile && loggedInUser && (
        isFollowing
          ? <button onClick={handleUnfollow} style={buttonStyle}>Unfollow</button>
          : <button onClick={handleFollow} style={buttonStyle}>Follow</button>
      )}

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '15px', marginTop: '10px' }}>
        <TabButton label="Listings" active={activeTab === 'listings'} onClick={() => setActiveTab('listings')} />
        <TabButton label={`Followers (${followers.length})`} active={activeTab === 'followers'} onClick={() => setActiveTab('followers')} />
        <TabButton label={`Following (${following.length})`} active={activeTab === 'following'} onClick={() => setActiveTab('following')} />
        {isOwnProfile && <TabButton label="Settings" active={activeTab === 'settings'} onClick={() => setActiveTab('settings')} />}
      </div>

      {/* Tab Content */}
      {activeTab === 'listings' && (
        userProducts.length === 0 ? (
          <p>No products yet.</p>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
            {userProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )
      )}

      {activeTab === 'followers' && <UserList users={followersData} navigate={navigate} />}
      {activeTab === 'following' && <UserList users={followingData} navigate={navigate} />}
      {activeTab === 'settings' && (
        <div style={{ paddingTop: '10px' }}>
          <label>
            <input
              type="checkbox"
              checked={showThumbnails}
              onChange={handleToggleThumbnails}
              style={{ marginRight: '8px' }}
            />
            Show thumbnail strip on product cards
          </label>
        </div>
      )}

      {isOwnProfile && notifCount > 0 && (
        <div style={{ marginTop: '20px', color: '#E38648', fontWeight: 'bold' }}>
          🔔 You have {notifCount} new follower{notifCount > 1 ? 's' : ''}!
        </div>
      )}
    </div>
  );
}

function TabButton({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: '6px 12px',
        borderRadius: '20px',
        border: active ? '2px solid #E38648' : '1px solid #ccc',
        background: active ? '#FFF3EA' : '#f9f9f9',
        cursor: 'pointer',
      }}
    >
      {label}
    </button>
  );
}

function UserList({ users, navigate }) {
  if (users.length === 0) return <p>No users to show.</p>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {users.map((user) => (
        <div
          key={user.username}
          onClick={() => navigate(`/profile/${user.username}`)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            cursor: 'pointer',
            padding: '8px',
            border: '1px solid #eee',
            borderRadius: '8px',
          }}
        >
          <img
            src={user.photo || generateAvatar(user.username)}
            alt={user.username}
            style={{ width: 40, height: 40, borderRadius: '50%', objectFit: 'cover' }}
          />
          <div>
            <div style={{ fontWeight: 'bold' }}>@{user.username}</div>
            <div style={{ fontSize: '14px', color: '#777' }}>{user.bio || 'No bio.'}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function getProfile(username) {
  return JSON.parse(localStorage.getItem(`profile_${username}`)) || {};
}

function generateAvatar(username) {
  return `https://api.dicebear.com/6.x/fun-emoji/svg?seed=${encodeURIComponent(username)}`;
}

const buttonStyle = {
  backgroundColor: '#E38648',
  color: '#fff',
  border: 'none',
  padding: '8px 14px',
  borderRadius: '6px',
  cursor: 'pointer',
  marginBottom: '10px',
};

const editButtonStyle = {
  padding: '8px 12px',
  backgroundColor: '#eee',
  border: '1px solid #ccc',
  borderRadius: '6px',
  cursor: 'pointer',
};

const saveButtonStyle = {
  backgroundColor: '#E38648',
  color: '#fff',
  border: 'none',
  padding: '10px 15px',
  borderRadius: '6px',
  cursor: 'pointer',
  marginTop: '10px',
};
