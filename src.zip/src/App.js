// ✅ Always start with imports
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import HomePage from './pages/homepage';
import ProductPage from './pages/productpage';
import SellPage from './pages/sellpage';
import SearchPage from './pages/searchpage';
import ProfilePage from './pages/profilepage';
import MyListingsPage from './pages/MyListingsPage';
import LoginPage from './pages/LoginPage';
import Navbar from './components/Navbar';
import AdminDashboard from './pages/AdminDashboard';


import { getTheme, setTheme } from './theme';
setTheme(getTheme()); // Apply theme immediately

function App() {
  const user = localStorage.getItem('kashi_user');

  return (
    <Router>
      <div style={{ paddingBottom: '70px' }}>
        <Routes>
          {/* Public route */}
          <Route path="/login" element={<LoginPage />} />

          {/* Redirect all other routes to login if not logged in */}
          {!user && <Route path="*" element={<Navigate to="/login" />} />}

          {/* Protected routes */}
          {user && (
            <>
              <Route path="/" element={<HomePage />} />
              <Route path="/product/:id" element={<ProductPage />} />
              <Route path="/sell" element={<SellPage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/profile/:username" element={<ProfilePage />} />
              <Route path="/my-listings" element={<MyListingsPage />} />
              <Route path="/admin" element={<AdminDashboard />} />
            </>
          )}
        </Routes>

        {user && <Navbar />}
      </div>
    </Router>
  );
}

export default App;
