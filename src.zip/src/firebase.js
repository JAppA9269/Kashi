// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from 'firebase/firestore';
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDPdX9UfPRn7QYZrBWxqQHXDeTwSCjImFA",
  authDomain: "kashi-1a368.firebaseapp.com",
  projectId: "kashi-1a368",
  storageBucket: "kashi-1a368.firebasestorage.app",
  messagingSenderId: "923799455185",
  appId: "1:923799455185:web:381ba8f57c126178fa4cf0",
  measurementId: "G-QVK71ESZ0B"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
export default db;