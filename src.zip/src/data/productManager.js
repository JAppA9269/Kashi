import baseProducts from './products';

const LOCAL_KEY = 'kashi_user_products';

export function getAllProducts() {
  const userProducts = JSON.parse(localStorage.getItem(LOCAL_KEY)) || [];
  return [...userProducts, ...baseProducts];
}

export function addProduct(newProduct) {
  const current = JSON.parse(localStorage.getItem(LOCAL_KEY)) || [];
  const updated = [{ ...newProduct, id: Date.now() }, ...current];
  localStorage.setItem(LOCAL_KEY, JSON.stringify(updated));
}
